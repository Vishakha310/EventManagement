﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class uFeedback : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public uFeedback()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                comboBox1.Text = row.Cells["EvIssd"].Value.ToString();
                textBox1.Text = row.Cells["EvName"].Value.ToString();
                comboBox2.Text = row.Cells["Organization"].Value.ToString();
                comboBox3.Text = row.Cells["Punctuality"].Value.ToString();
                comboBox4.Text = row.Cells["Hospitality"].Value.ToString();
            }
        }
        private void LoadEventIds()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT Evid FROM Event";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader["Evid"].ToString());
            }

            reader.Close();
            con.Close();
        }

        private void LoadFeedbackData()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM Feedback";
            SqlDataAdapter sd = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void ClearTextBoxes()
        {
            comboBox1.Text = textBox1.Text = comboBox2.Text = comboBox3.Text = comboBox4.Text = "";
        }

        private void uFeedback_Load(object sender, EventArgs e)
        {
            LoadEventIds();
            LoadFeedbackData();
            dataGridView1.ClearSelection();
        }

        private void button1_Click(object sender, EventArgs e)
        {
   
            int selectedIndex1 = comboBox2.SelectedIndex + 1;
            int selectedIndex2 = comboBox3.SelectedIndex + 1;
            int selectedIndex3 = comboBox4.SelectedIndex + 1;

            int overall = (selectedIndex1 + selectedIndex2 + selectedIndex3) / 3;


            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "INSERT INTO Feedback (EvId, EvName, Organization, Punctuality, Hospitality, OverAll) " +
                "VALUES (@eventId, @eventName, @Organization, @punctuality, @hospitality, @overall)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@eventId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@eventName", textBox1.Text);
            cmd.Parameters.AddWithValue("@Organization", comboBox2.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@punctuality", comboBox3.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@hospitality", comboBox4.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@overall", overall);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Feedback Record Inserted Successfully...");
                LoadFeedbackData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Insert Operation Can't Be Completed");
            }

            ClearTextBoxes();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedIndex1 = comboBox2.SelectedIndex + 1;
            int selectedIndex2 = comboBox3.SelectedIndex + 1;
            int selectedIndex3 = comboBox4.SelectedIndex + 1;

            int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int feedbackId = Convert.ToInt32(selectedRow.Cells["FId"].Value);

            int overall = (selectedIndex1 + selectedIndex2 + selectedIndex3) / 3;

            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "UPDATE Feedback SET EvName = @eventName, Organization = @Organization, Punctuality = @punctuality, " +
                           "Hospitality = @hospitality, OverAll = @overall WHERE FId = @feedbackId";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@eventName", textBox1.Text);
            cmd.Parameters.AddWithValue("@Organization", comboBox2.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@punctuality", comboBox3.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@hospitality", comboBox4.SelectedIndex + 1);
            cmd.Parameters.AddWithValue("@overall", overall);
            cmd.Parameters.AddWithValue("@feedbackId", feedbackId);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Feedback Record Updated Successfully...");
                LoadFeedbackData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Update Operation Can't Be Completed.");
            }

            ClearTextBoxes();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
                int feedbackId = Convert.ToInt32(selectedRow.Cells["FId"].Value);

                if (MessageBox.Show("Are you sure you want to delete this feedback record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    SqlConnection con = new SqlConnection(ConString);
                    con.Open();
                    string query = "DELETE FROM Feedback WHERE FId = @feedbackId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@feedbackId", feedbackId);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Feedback Record Deleted Successfully...");
                        LoadFeedbackData();
                    }
                    else
                    {
                        MessageBox.Show("Something Went Wrong. Delete Operation Can't Be Completed.");
                    }

                    ClearTextBoxes();
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a feedback record to delete.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            dataGridView1.ClearSelection();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBox1.Text))
            {
                string selectedEventId = comboBox1.Text;
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "SELECT EvName FROM Event WHERE Evid = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedEventId);

                object eventName = cmd.ExecuteScalar();
                if (eventName != null)
                {
                    textBox1.Text = eventName.ToString();
                }

                con.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            udashboard form = new udashboard();
            form.Show();
        }
    }
}
