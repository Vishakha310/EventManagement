﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class uregister : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public uregister()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ulogin form = new ulogin();
            form.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string email = textBox2.Text;
            string mobile = textBox3.Text;
            string username = textBox4.Text;
            string password = textBox5.Text;

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("All Fields Are Required");
            }
            else
            {
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "INSERT INTO uregister (name, email, mobile, username, password) " +
                                   "VALUES (@name, @email, @mobile, @username, @password);";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@mobile", mobile);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Registration successful!");
                    this.Hide();
                    udashboard form = new udashboard();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Registration failed. Please try again.");
                }
                con.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void uregister_Load(object sender, EventArgs e)
        {

        }
    }
}
