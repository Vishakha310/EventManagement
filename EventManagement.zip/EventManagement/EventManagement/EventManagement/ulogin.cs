﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class ulogin : Form
    {
        String ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public ulogin()
        {
            InitializeComponent();
        }

        private void ulogin_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login form = new Login();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Both Fields Are Required");
            }
            else
            {
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                String query = "SELECT * FROM uregister WHERE username=@a AND password=@b";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@a", textBox1.Text);
                cmd.Parameters.AddWithValue("@b", textBox2.Text);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    this.Hide();
                    udashboard dash = new udashboard();
                    dash.Show();
                }
                else
                {
                    MessageBox.Show("UserName Or Password is wrong....");
                }
                con.Close();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = "";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            uregister form = new uregister();
            form.Show();
        }
    }
}
